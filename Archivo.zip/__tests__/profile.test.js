const puppeteer = require('puppeteer');

describe('Perfil de Usuario', () => {
  let browser;
  let page;

  beforeAll(async () => {
    browser = await puppeteer.launch({ headless: "new" });
    page = await browser.newPage();

    // Iniciar sesión antes de las pruebas
    await page.goto('http://localhost:3000/login.html');

    // Verificar que estamos en la página de login
    const loginButtonExists = await page.$('#login_button') !== null;
    console.log('Login button exists:', loginButtonExists);
    
    // Asegurarnos de que los selectores son correctos
    await page.screenshot({ path: 'login-page.png' }); // Tomar una captura de pantalla para depuración

    await page.type('#email', 'tu_email'); // Reemplaza 'tu_email' con el email de prueba
    await page.type('#password', 'tu_password'); // Reemplaza 'tu_password' con la contraseña de prueba
    await page.click('#login_button'); // Reemplaza con el selector del botón de login
    await page.waitForNavigation();

    // Tomar una captura de pantalla después de iniciar sesión
    await page.screenshot({ path: 'profile-page.png' }); // Tomar una captura de pantalla para depuración
  });

  afterAll(async () => {
    await browser.close();
  });

  test('Cargar el perfil de usuario', async () => {
    await page.goto('http://localhost:3000/profile.html');
    await page.waitForSelector('#user_name');
    
    const userName = await page.$eval('#user_name', el => el.textContent);
    expect(userName).toMatch(/Bienvenid@, .*/);
  });

  test('Reservar una clase', async () => {
    await page.goto('http://localhost:3000/profile.html');
    await page.waitForSelector('#calendario');
    
    // Simular un clic en una fecha específica
    await page.click('.fc-daygrid-day[data-date="2024-06-15"]'); // Reemplaza con una fecha disponible en tu calendario
    await page.waitForSelector('#horariosContenido');
    
    // Simular un clic en el botón de reservar cupo
    await page.click('.my-button-reservas');
    await page.waitForSelector('#confirmationModal');

    const confirmationText = await page.$eval('#confirmationText', el => el.textContent);
    expect(confirmationText).toMatch(/Tu clase ha sido reservada/);
  }, 10000); // Aumenta el tiempo de espera a 10 segundos

  test('Logout', async () => {
    await page.goto('http://localhost:3000/profile.html');
    await page.click('#logout');
    
    const url = await page.url();
    expect(url).toBe('http://localhost:3000/');
  });
});
