module.exports = {
    launch: {
      headless: false, // Cambia a true si prefieres que el navegador no se abra
      slowMo: 50
    },
    browserContext: 'default'
  };
  